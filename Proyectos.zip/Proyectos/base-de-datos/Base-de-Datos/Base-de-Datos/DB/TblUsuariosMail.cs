﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblUsuariosMail
    {
        public int CodUsuario { get; set; }
        public string Mail { get; set; }
        public string Tipo { get; set; }
        public int IdMail { get; set; }

        public virtual TblUsuarios CodUsuarioNavigation { get; set; }
    }
}
