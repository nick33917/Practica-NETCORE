﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblItemEvaluacion
    {
        public TblItemEvaluacion()
        {
            TblEvaluacion = new HashSet<TblEvaluacion>();
        }

        public int IdItemEvaluacion { get; set; }
        public string Descripcion { get; set; }

        public virtual ICollection<TblEvaluacion> TblEvaluacion { get; set; }
    }
}
