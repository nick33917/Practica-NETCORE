﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildExecutionGrupo
    {
        public long IdReorgExecutionGrupo { get; set; }
        public string Groupname { get; set; }
        public DateTime? Horainicio { get; set; }
        public DateTime? Horafin { get; set; }
        public long? IdHistoryStatsInicio { get; set; }
        public long? IdHistoryStatsFin { get; set; }
        public long? IdReorgExecutionLogInicio { get; set; }
        public long? IdReorgExecutionLogFin { get; set; }
        public long? CantidadTablasProcesadas { get; set; }
        public long? CantidadTablasRebuild { get; set; }
        public long? CantidadTablasUpStat { get; set; }
        public long? CantidadTablasVacias { get; set; }
        public string Status { get; set; }
    }
}
