﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblPeriodos
    {
        public TblPeriodos()
        {
            TblPeriodoDetalle = new HashSet<TblPeriodoDetalle>();
        }

        public int CodPeriodo { get; set; }
        public string DescripcionPeriodo { get; set; }

        public virtual ICollection<TblPeriodoDetalle> TblPeriodoDetalle { get; set; }
    }
}
