﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildExecutionLogEvento
    {
        public long IdEventoLog { get; set; }
        public long? IdReorgExecutionLog { get; set; }
        public string Origen { get; set; }
        public DateTime? Fechahora { get; set; }
        public string Mensaje { get; set; }
        public string JobId { get; set; }
    }
}
