﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblPeerReview
    {
        public string CodTipoDocumento { get; set; }
        public string CodAcuerdo { get; set; }
        public int NumGalar { get; set; }
        public string CodEstadoPeer { get; set; }
        public int CodUsuarioController { get; set; }
        public int CodUsuarioRevisor { get; set; }
        public int CodUsuario { get; set; }
        public DateTime FechaLimite { get; set; }

        public virtual TblEstadosPeerReview CodEstadoPeerNavigation { get; set; }
        public virtual TblDocumentosPeerReview CodTipoDocumentoNavigation { get; set; }
    }
}
