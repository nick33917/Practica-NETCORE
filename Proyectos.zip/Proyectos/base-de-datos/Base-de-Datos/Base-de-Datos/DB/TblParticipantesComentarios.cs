﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblParticipantesComentarios
    {
        public int CodParticipante { get; set; }
        public int NumGalar { get; set; }
        public int CodTipoGalar { get; set; }
        public int CodAcuerdo { get; set; }
        public int CodUsuarioAlta { get; set; }
        public string Comentario { get; set; }
        public int Ranking { get; set; }
        public int CodGrupo { get; set; }
        public int AnioFiscal { get; set; }
    }
}
