﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblUsuariosTelefono
    {
        public int CodUsuario { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public int IdTel { get; set; }

        public virtual TblUsuarios CodUsuarioNavigation { get; set; }
    }
}
