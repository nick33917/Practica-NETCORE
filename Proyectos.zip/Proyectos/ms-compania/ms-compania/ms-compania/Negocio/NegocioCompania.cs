﻿using AutoMapper;
using Base_de_Datos.DB;
using ms_compania.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_compania.Negocio
{
    public class NegocioCompania : INegocioCompania
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public NegocioCompania(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public void BorrarCompania(int codCompania)
        {
            throw new NotImplementedException();
        }

        public void CrearCompania(Compania Compania)
        {
            throw new NotImplementedException();
        }

        public Compania GetCompania(int codCompania)
        {
            throw new NotImplementedException();
        }

        public List<Compania> GetCompanias()
        {
            return _mapper.Map<List<Compania>>(_db.TblCompany.ToList());
        }

        public void ModificarCompania(int codCompania, Compania categoria)
        {
            throw new NotImplementedException();
        }
    }
}
