﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_categorias.Modelo;
using Base_de_Datos.DB;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;

namespace ms_categorias.Negocio
{
    public class NegocioCategorias : INegocioCategorias
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public NegocioCategorias(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        //Command
        public void BorrarCategoria(int codCategoria)
        {
            var resutl = _db.TblCategorias.FirstOrDefault(c => c.CodCategoria == codCategoria);

            _db.TblCategorias.Remove(resutl);

            _db.SaveChanges();
        }

        //Commmand
        public void CrearCategoria(Categoria categoria)
        {
            //var resutl = _mapper.Map<TblCategorias>(categoria);

            TblCategorias categorias = new TblCategorias
            {
                CodCategoria = categoria.CodCategoria,
                Level = categoria.Level,
                NombreCategoria = categoria.NombreCategoria,
                Skill = categoria.Skill
            };

            _db.TblCategorias.Add(categorias);

            _db.SaveChanges();
        }

        //Query
        public Categoria GetCategoria(int codCategoria)
        {
            return _mapper.Map<Categoria>(_db.TblCategorias.FirstOrDefault(c => c.CodCategoria == codCategoria));
        }

        //Query
        public List<Categoria> GetCategorias()
        {
            return _mapper.Map<List<Categoria>>(_db.TblCategorias.ToList());
        }

        //Command
        public void ModificarCategoria(int codCategoria,Categoria categoria)
        {
            var resutl = _db.TblCategorias.FirstOrDefault(c => c.CodCategoria == codCategoria);

            if (categoria.Level != null)
            {
                resutl.Level = categoria.Level;
            }

            if (categoria.NombreCategoria != null)
            {
                resutl.NombreCategoria = categoria.NombreCategoria;
            }

            if (categoria.Skill != null)
            {
                resutl.Skill = categoria.Skill;
            }

            _db.Entry(resutl).State = EntityState.Modified;
            _db.SaveChanges();
        }
    }
}
